/*********************************************************
 *Program Filename:list.c
 *Author: Stephanie Babb
 *Date: June 11, 2017
 *Description: The implimentation of functions for a linked list
 *Input:Needs list.h file with structs
 *Output:None
 *********************************************************/
#include "list.h"
#include <stdio.h>
#include <stdlib.h>

/*************************************************************
 *Function:init
 *Description:initializes the link list by setting the pointer to NULL
 *Parameters:pointer/address to a list
 *Pre-Conditions: An instance of a list has been created and passed
 *Post-Conditions:The head and tail pointers of the list are assigned to NULL
 *Return:None
 *************************************************************/
void init(struct list *l){
	(*l).head=NULL;
	(*l).tail=NULL;

}

/*************************************************************
 *Function:size
 *Description:Returns the size of the list (amount of data)
 *Parameters:list
 *Pre-Conditions:The list has been initialized
 *Post-Conditions:the size is returned
 *Return:the size of the linked list
 *************************************************************/
int size(struct list l){
	int c=0;
	struct node *temp=l.head;
	while(temp!=NULL){
		temp=temp->next;
		c+=1;
	}
	return c;
}

/*************************************************************
 *Function:print
 *Description: prints the contents of the list to the screen
 *Parameters: a list
 *Pre-Conditions:The list has been initialized
 *Post-Conditions:None
 *Return:None
 *************************************************************/
void print(struct list l){
	struct node *temp=l.head;
	while(temp!=NULL){
	   	printf("%d",temp->val);
		temp=temp->next;
	}
	printf("\n");
}

/*************************************************************
 *Function:push_front
 *Description:Puts a value on the front of the list
 *Parameters:pointer to/address of a list, the value to put in the node
 *Pre-Conditions:The list exists and has been initialized
 *Post-Conditions:There is a new node with the passed value on the list
 *Return:None
 *************************************************************/
void push_front(struct list *l, int i){
	struct node *n;
	n=(struct node*)malloc(sizeof(struct node));
	n->val=i;
	if((*l).head==NULL){
	   	n->next=NULL;
		(*l).head=n;
		(*l).tail=n;		
	}else{
		n->next=(*l).head;
		(*l).head=n;
	}
	
}

/*************************************************************
 *Function:push_back
 *Description:Puts a new value on the back of the list
 *Parameters:pointer to/address of a list, the value to put in the node
 *Pre-Conditions:The list has been initialized
 *Post-Conditions:There is a new node with the passed value on the list
 *Return:None
 *************************************************************/
void push_back(struct list *l, int i){
	struct node *n;
	n=(struct node*)malloc(sizeof(struct node));
	n->next=NULL;
	n->val=i;
	if((*l).head==NULL){
		(*l).head=n;
		(*l).tail=n;		
	}else{
		(*l).tail->next=n;
		(*l).tail=n;
	}

}

/*************************************************************
 *Function:front
 *Description:returns the first value in the list
 *Parameters:a list
 *Pre-Conditions:the list is passed in and not empty
 *Post-Conditions:The value is returned
 *Return: the value at the front of the list (least recently put on)
 *************************************************************/
int front(struct list l){
   return l.head->val;
}

/*************************************************************
 *Function:back
 *Description:returns the last value in the list
 *Parameters:a list
 *Pre-Conditions:The list is not empty
 *Post-Conditions:the value is returned
 *Return: the value at the back of the list (most recently put on)
 *************************************************************/
int back(struct list l){
   return l.tail->val;
}

/*************************************************************
 *Function:pop_back
 *Description:Removes the value at the end of the list, returns the value sotred in it, and frees the memory
 *Parameters:pointer to/address of a list
 *Pre-Conditions: The list is initialized and not empty
 *Post-Conditions:The list has one less value and the tail pointer is changed
 *Return:the value at the back of the list (most recently put on)
 *************************************************************/
int pop_back(struct list *l){
   int i;
   	if((*l).head!=(*l).tail){
   		struct node *current=(*l).head;
   		i=(*l).tail->val;
		while((current->next)!=(*l).tail){
			current=current->next;
		}
		(*l).tail=current;
		free((*l).tail->next);
		(*l).tail->next=NULL;
	}else if((*l).head!=NULL){
		i=(*l).tail->val;
		free((*l).tail);
		(*l).tail=NULL;
		(*l).head=NULL;
	}
	return i;
}

/*************************************************************
 *Function:remove_front
 *Description: Removes the value at the front of the list, returns the value stored in it, and frees the memory
 *Parameters:pointer to/address of a list
 *Pre-Conditions:The list is initialized and not empty
 *Post-Conditions:The list had one less value and the head pointer is changed
 *Return:the value at the front of the list (least recently put on)
 *************************************************************/
int remove_front(struct list *l){
	int i;
   	if((*l).head!=(*l).tail){
   	struct node *temp;
	temp=(*l).head->next;
	i=(*l).head->val;
	free((*l).head);
	(*l).head=temp;
	}else if((*l).head!=NULL){
		i=(*l).head->val;
		free((*l).tail);
		(*l).tail=NULL;
		(*l).head=NULL;
	}
	return i;
}

/*************************************************************
 *Function:empty
 *Description:Tests if the list is empty or not
 *Parameters:a list
 *Pre-Conditions:The list passed has been innitialized
 *Post-Conditions:The value of true or false is returned
 *Return: 0 if the list is not empty, 1 if it is
 *************************************************************/
int empty(struct list l){
	if(l.head==NULL){
		return 1;
	}
	return 0;
}

/*************************************************************
 *Function:delete
 *Description:Frees the memory for each node in the list
 *Parameters:pointer to/address of a linked list
 *Pre-Conditions:The list passed is not empty
 *Post-Conditions:The memory used for the list has been freed
 *Return:None
 *************************************************************/
void delete(struct list *l){
	struct node *temp=(*l).head;
	while((*l).head!=(*l).tail){
		while(temp->next!=(*l).tail){
			temp=temp->next;
		}
		free((*l).tail);
		(*l).tail=temp;
		(*l).tail->next=NULL;
	}
	free((*l).head);
	(*l).head=NULL;
	(*l).tail=NULL;
}
