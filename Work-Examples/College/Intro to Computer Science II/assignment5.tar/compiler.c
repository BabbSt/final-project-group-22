/**************************************************************
 *Program Filename: compiler.c
 *Author: Stephanie Babb
 *Date: June 11, 2017
 *Description: Takes in a string of characters from the user then uses a linked list stack to check if it has correct bracket matching
 *Input: User input of a string of {}/()/[]
 *Output:Prints to screen if the input is acceptable or not.
 *************************************************************/
#include "list.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*************************************************************
 *Function:main
 *Description:Creates a list, asks the user for input, uses the list to test the input
 *Parameters:None
 *Pre-Conditions:None
 *Post-Conditions:It is printed to the screen whether or not the input is valid
 *Return:None
 *************************************************************/
int main(){
	struct list l;
	init(&l);
	int acceptable=1;
	int closed=0;
	char str[256];
	int i;
	int t;
	printf("Enter the code you wish to check: ");
	scanf("%s",&str);
	for(i=0;i<strlen(str);i++){
	//	printf("%c",str[i]);
		if(str[i]=='{'||str[i]=='['||str[i]=='('){
			switch(str[i]){
			   case '{':
			      push_back(&l,1);
			      break;
			   case '[':
			      push_back(&l,0);
			      break;
			   case '(':
			      push_back(&l,2);
			      break;
			}
		   	closed+=1;
		}else if(str[i]=='}'||str[i]==']'||str[i]==')'){
		   	closed-=1;
			switch(str[i]){
			   case '}':
			      if(pop_back(&l)!=1){
			      	acceptable=0;
				break;
			      }
			      break;
			   case ']':
			      if(pop_back(&l)!=0){
			      	acceptable=0;
				break;
			      }
			      break;
			   case ')':
			      if(pop_back(&l)!=2){
			      	acceptable=0;
				break;
			      }
			      break;
			}
		}
	}
	//printf("%d \n",acceptable);
	//printf("%d \n",closed);
	if(acceptable==1&&closed==0){
		printf("Your code is acceptable :)\n");
	}else{
		printf("Your code is UNACCEPTABLE :(\n");
	}
	delete(&l);
	return 0;
}
