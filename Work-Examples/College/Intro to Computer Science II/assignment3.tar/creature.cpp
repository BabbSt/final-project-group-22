
/****************************************************************
 *Program:creature.cpp
 *Author: Stephanie Babb
 *Date: May 14, 2017
 *Description: Sets up functionality for a creature type with getters and setters
 *Input:None
 *Output:None
 ***************************************************************/
#include "creature.h"
#include <stdlib.h>
#include <time.h>
//getters:return values of member variables
int creature::getType(){
	return type;
}

/******************************************************************
 *Function:getDamage
 *Description:gets a random damage value for a creature
 *Parameters:none
 *Pre-conditions:the strength is defined
 *Post-conditions:none
 *Return:the damage value
 ****************************************************************/
int creature:: getDamage(){
   	srand(time(NULL));
	return (rand() % strength)+1;
}

int creature:: getLifePoints(){
	return lifepoints;
}

string creature:: getName(){
	return name;
}

double creature::getPayoff(){
	return payoff;
}

double creature::getCost(){
	return cost;
}
//setters:set the values of member variables
void creature::setType(int i){
	type=i;
}

void creature::setStrength(int i){
	strength = i;
}

void creature::setLifePoints(int i){
	lifepoints = i;
}

void creature::setName(string s){
	name = s;
}

void creature::setPayoff(double d){
	payoff = d;
}

void creature::setCost(double d){
	cost = d;
}
