
/****************************************************************
 *Program: world.h
 *Author:Stephanie Babb
 *Date: May 14, 2017
 *Description: Header file fo the world cladd, sets up meber variables
 *Input:None
 *Output:None
 ***************************************************************/
#include "creature.h"
#include "human.h"
#include "elf.h"
#include "balrog.h"
#include "cyber.h"
#include <string>

using namespace std;

class world{
   private:
      double money;
      int num_h;
      int num_e;
      int num_c;
      int num_b;
      human *hs;
      elf *es;
      cyber *cs;
      balrog *bs;
   public:
      world(double);
      ~world();
      world(const world &);
      void operator=(const world &);
      double getMoney();
      int getnum_h();
      int getnum_e();
      int getnum_c();
      int getnum_b();
      void setnum_h(int);
      void setnum_e(int);
      void setnum_c(int);
      void setnum_b(int);
      void setMoney(double);
      void buyHuman();
      void buyElf();
      void buyCyber();
      void buyBalrog();
      void removeHuman(string);
      void removeElf(string);
      void removeCyber(string);
      void removeBalrog(string);
      void battle(creature *, creature *);
      void playGame();
      human *findHuman();
      elf *findElf();
      cyber *findCyber();
      balrog *findBalrog();
    // void test(); 
};
