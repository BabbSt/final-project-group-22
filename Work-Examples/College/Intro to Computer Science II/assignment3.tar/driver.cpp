
/****************************************************************
 *Program: driver.cpp
 *Author: Stephanie Babb
 *Date: May 14, 2017
 *Description: Holds main, creates a world and runs the game
 *Input: Amount of money input form user
 *Output:None
 ***************************************************************/
#include "world.h"
#include <iostream>
using namespace std;
int main(){
   double m;
   cout<<"How much money would you like to put into your world?: "<<endl;
   cin>>m;
   world w(m);
   w.playGame();
   //w.test();
   return 0;
}
