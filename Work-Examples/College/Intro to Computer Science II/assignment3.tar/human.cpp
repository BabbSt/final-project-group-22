
/****************************************************************
 *Program: human.cpp
 *Author: Stephanie Babb
 *Date: May 14,2017
 *Description: Holds the constructor for a human
 *Input:None
 *Output:None
 ***************************************************************/
#include "human.h"

human::human(){
   type=1;
   strength=3;
   lifepoints=5;
   payoff=10.00;
   cost=5.00;
}
