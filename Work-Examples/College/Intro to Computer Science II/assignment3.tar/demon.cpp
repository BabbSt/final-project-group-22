
/****************************************************************
 *Program:demon.cpp
 *Author: Stephanie Babb
 *Date: May 14, 2017
 *Description: Holds the constructor and get damage function for a demon
 *Input:None
 *Output:None
 ***************************************************************/
#include "demon.h"
#include <stdlib.h>
#include <time.h>

demon::demon(){
   strength=0;
   lifepoints=0;
   payoff=0;
   cost=0;
}

/******************************************************************
 *Function:getDamage
 *Description:Sees if the demon adds 50 point to its attack
 *Parameters:none
 *Pre-conditions:none
 *Post-conditions:none
 *Return:The value of the demons attack
 ****************************************************************/
int demon::getDamage(){
   	srand (time(NULL));
   	if((rand() % 100)<5){
		return strength+50;
	}else{
		return strength;
	}
}
