
/****************************************************************
 *Program: creature.h
 *Author: Stephanie BAbb
 *Date: May 14, 2017
 *Description:Hedaer file for the creature class, established member variables
 *Input:None
 *Output:None
 ***************************************************************/
#ifndef CREATURE_H
#define CREATURE_H
#include <string>

using namespace std;

class creature{
   protected:
        int type;
	int strength;
	int lifepoints;
	string name;
	double payoff;
	double cost;

   public:
      //creature();
      int getType();
      virtual int getDamage();
      int getLifePoints();
      string getName();
      double getPayoff();
      double getCost();
      void setType(int);
      void setStrength(int);
      void setLifePoints(int);
      void setName(string);
      void setPayoff(double);
      void setCost(double);

};
#endif
