
/****************************************************************
 *Program:human.h
 *Author: Stephanie Babb
 *Date: May 14, 2017
 *Description:Header file for the human class
 *Input:None
 *Output:None
 ***************************************************************/
#include "creature.h"
class human:public creature{
   private:

   public:
      human();
};
