
/****************************************************************
 *Program:cyber.cpp
 *Author: Stephanie Babb
 *Date: May 14, 2017
 *Description: holds the constructor for a cyberdemon
 *Input:None
 *Output:None
 ***************************************************************/
#include "cyber.h"

cyber::cyber(){
   type=3;
   strength=8;
   lifepoints=222;
   payoff=7.00;
   cost=8.50;

}
