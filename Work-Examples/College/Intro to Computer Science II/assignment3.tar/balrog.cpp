
/****************************************************************
 *Program:balrog.cpp
 *Author: Stephanie Babb
 *Date:May 14, 2017
 *Description:Holds the constructor and get damage function for a balrog
 *Input:None
 *Output:None
 ***************************************************************/
#include "balrog.h"
#include <stdlib.h>
#include <time.h>

balrog::balrog(){
   type=4;
   strength=9;
   lifepoints=19;
   payoff=8.00;
   cost=9.00;
}

/******************************************************************
 *Function: getDamage
 *Description: sets special balrog double attack value
 *Parameters:none
 *Pre-conditions:none
 *Post-conditions:none
 *Return:the damage the balrog is inflicting
 ****************************************************************/
int balrog::getDamage(){
	srand(time(NULL));
	return ((rand()%strength)+1+(rand()% strength)+1);	
}
