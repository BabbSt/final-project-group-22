
/****************************************************************
 *Program: elf.h
 *Author: Stephanie Babb
 *Date: May 14, 2017
 *Description:Header file for the elf class
 *Input:None
 *Output:None
 ***************************************************************/
#include "creature.h"
class elf:public creature{
   private:

   public:
	elf();
	int getDamage();
};
