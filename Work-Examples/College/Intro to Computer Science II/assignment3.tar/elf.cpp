
/****************************************************************
 *Program:elf.cpp
 *Author:Stephanie Babb
 *Date: May 14, 2017
 *Description:Holds the constructor and get damge function for an els
 *Input:None
 *Output:None
 ***************************************************************/
#include "elf.h"
#include <stdlib.h>
#include <time.h>

elf::elf(){
   type=2;
   strength=6;
   lifepoints=17;
   payoff=8.00;
   cost=7.50;

}

/******************************************************************
 *Function:getDamage
 *Description:Sees if the elf adds magical damage
 *Parameters:None
 *Pre-conditions:None
 *Post-conditions:None
 *Return:the damage the elf inflicts
 ****************************************************************/
int elf::getDamage(){
	srand (time(NULL));
	if((rand()% 10)==0){
		return strength*2;
	}else{
		return strength;
	}
}
