
/****************************************************************
 *Program:demon.h
 *Author: Stephanie Babb
 *Date:May 14, 2017
 *Description: Header file for the demon class
 *Input:None
 *Output:None
 ***************************************************************/
#ifndef DEMON_H
#define DEMON_H
#include "creature.h"
class demon: public creature{

   public:
      demon();
      int getDamage();
};
#endif
