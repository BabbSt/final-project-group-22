
/****************************************************************
 *Program: cyber.h
 *Author: Stephanie Babb
 *Date: May 14, 2017
 *Description:Header file for the cyberdemon class
 *Input:None
 *Output:None
 ***************************************************************/
#include "demon.h"
class cyber:public demon{
   private:

   public:
      cyber();
};
