
/****************************************************************
 *Program:balrog.h
 *Author:Stephanie Babb
 *Date: May 14, 2017
 *Description: Hedaer file for the balrog class
 *Input:None
 *Output:None
 ***************************************************************/
#include "demon.h"
class balrog:public demon{
   private:

   public:
      balrog();
      int getDamage();
};
