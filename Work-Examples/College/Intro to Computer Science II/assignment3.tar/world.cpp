/****************************************************************
 *Program:world.cpp
 *Author: Stephanie Babb
 *Date:May 14, 2017
 *Description:The actual design of the game, where the game takes palce, uses functions to simulate gameplay
 *Input:Some user input
 *Output:None
 ***************************************************************/
#include "world.h"
#include <iostream>
#include <string>
using namespace std;
//non default constructor, sets initial money value
world::world(double m){
   money=m;
   hs=NULL;
   es=NULL;
   cs=NULL;
   bs=NULL;
   num_h=0;
   num_e=0;
   num_c=0;
   num_b=0;
}
//big 3
world::~world(){
   delete [] hs;
   delete [] es;
   delete [] cs;
   delete [] bs;
}

world::world(const world &other){
   money=other.money;
   num_h=other.num_h;
   num_e=other.num_e;
   num_c=other.num_c;
   num_b=other.num_b;
   if(num_h==0){
      hs=NULL;
   }else{
      hs=new human[num_h];
      for(int i=0; i<num_h; i++){
         hs[i]=other.hs[i];
      }
   }
   if(num_e==0){
      es=NULL;
   }else{
      es=new elf[num_e];
      for(int i=0; i<num_e; i++){
         es[i]=other.es[i];
      } 
   }
   if(num_c==0){
      cs=NULL;
   }else{
      cs=new cyber[num_c];
      for(int i=0; i<num_c; i++){
         cs[i]=other.cs[i];
      }  
   }
   if(num_b==0){
   }else{
      bs=new balrog[num_b];
      for(int i=0; i<num_b; i++){
         bs[i]=other.bs[i];
      }  
   }
}

void world:: operator=(const world &other){
   delete [] hs;
   delete [] es;
   delete [] cs;
   delete [] bs;
   money=other.money;
   num_h=other.num_h;
   num_e=other.num_e;
   num_c=other.num_c;
   num_b=other.num_b;
   if(num_h==0){
      hs=NULL;
   }else{
      hs=new human[num_h];
      for(int i=0; i<num_h; i++){
         hs[i]=other.hs[i];
      }
   }
   if(num_e==0){
      es=NULL;
   }else{
      es=new elf[num_e];
      for(int i=0; i<num_e; i++){
         es[i]=other.es[i];
      } 
   }
   if(num_c==0){
      cs=NULL;
   }else{
      cs=new cyber[num_c];
      for(int i=0; i<num_c; i++){
         cs[i]=other.cs[i];
      }  
   }
   if(num_b==0){
   }else{
      bs=new balrog[num_b];
      for(int i=0; i<num_b; i++){
         bs[i]=other.bs[i];
      }  
   }
}
//getters: return member variable values
double world:: getMoney(){
   return money;
}
int world::getnum_h(){
   return num_h;
}
int world::getnum_e(){
   return num_e;
}
int world::getnum_c(){
   return num_c;
}
int world::getnum_b(){
   return num_b;
}
//Setters: set member variable values
void world::setnum_h(int i){
   num_h=i;
}
void world::setnum_e(int i){
   num_e=i;
}
void world::setnum_c(int i){
   num_c=i;
}
void world::setnum_b(int i){
   num_b=i;
}
void world::setMoney(double d){
	money=d;
}
/******************************************************************
 *Function:buyHuman
 *Description: Grows the human array by one, creates a new human and allows user to set its name, subtracts value of human from overall money
 *Parameters:None
 *Pre-conditions:An initial money value has been set and the hs array has been created
 *Post-conditions:The hs array is longer by 1
 *Return:None
 ****************************************************************/
void world::buyHuman(){
   	human h;
	string s;
	cout<<"Enter a name for your new human: "<<endl;
	cin>>s;
	h.setName(s);
	money-=h.getCost();
	num_h+=1;
	human *temp=new human[num_h];
	for(int i=0;i<num_h-1;i++){
		temp[i]=hs[i];
	}
	temp[num_h-1]=h;
	delete [] hs;
	hs=temp;	
}

/******************************************************************
 *Function:buyElf
 *Description: Grows the elf array by one, creates a new elf and allows user to set its name, subtracts value of elf from overall money
 *Parameters:None
 *Pre-conditions:An initial money value has been set and the es array has been created
 *Post-conditions:The es array is longer by 1
 *Return:None
 ****************************************************************/
void world::buyElf(){
   	elf e;
	string s;
	cout<<"Enter a name for your new elf: "<<endl;
	cin>>s;
	e.setName(s);
	money-=e.getCost();
	num_e+=1;
	elf *temp=new elf[num_e];
	for(int i=0;i<num_e-1;i++){
		temp[i]=es[i];
	}
	temp[num_e-1]=e;
	delete [] es;
	es=temp;	
}
/******************************************************************
 *Function:buyCyber
 *Description: Grows the cyberdemon array by one, creates a new cyberdemon and allows user to set its name, subtracts value of cyberdemon from overall money
 *Parameters:None
 *Pre-conditions:An initial money value has been set and the cs array has been created
 *Post-conditions:The cs array is longer by 1
 *Return:None
 ****************************************************************/
void world::buyCyber(){
   	cyber c;
	string s;
	cout<<"Enter a name for your new cyberdemon: "<<endl;
	cin>>s;
	c.setName(s);
	money-=c.getCost();
	num_c+=1;
	cyber *temp=new cyber[num_c];
	for(int i=0;i<num_c-1;i++){
		temp[i]=cs[i];
	}
	temp[num_c-1]=c;
	delete [] cs;
	cs=temp;	
}
/******************************************************************
 *Function:buyBalrog
 *Description: Grows the balrog array by one, creates a new balrog and allows user to set its name, subtracts value of balrog from overall money
 *Parameters:None
 *Pre-conditions:An initial money value has been set and the bs array has been created
 *Post-conditions:The bs array is longer by 1
 *Return:None
 ****************************************************************/
void world::buyBalrog(){
   	balrog b;
	string s;
	cout<<"Enter a name for your new balrog: "<<endl;
	cin>>s;
	b.setName(s);
	money-=b.getCost();
	num_b+=1;
	balrog *temp=new balrog[num_b];
	for(int i=0;i<num_b-1;i++){
		temp[i]=bs[i];
	}
	temp[num_b-1]=b;
	delete [] bs;
	bs=temp;	
}
/******************************************************************
 *Function:removeHuman
 *Description:Deletes a human that has no more life points, shrinks array by 1
 *Parameters:Name of human
 *Pre-conditions:A human has lost all of its lifepoints
 *Post-conditions:The human is removed from the world
 *Return:None
 ****************************************************************/
void world::removeHuman(string n){ 
   num_h-=1;
   int j;
   bool found =false;
   human *temp=new human[num_h];
   for(int i=0; i<num_h+1; i++){
      	if(found==false){
		j=i;
	}else{
		j=i-1;
	}
   	if(hs[i].getName()!=n){
		temp[j]=hs[i];
	}else{
		found=true;
	}
   }
   delete [] hs;
   hs=temp;
   cout<<"Your human "<<n<<" is no longer in the world"<<endl;
}	
/******************************************************************
 *Function:removeElf
 *Description:Deletes an elf that has no more life points, shrinks array by 1
 *Parameters:Name of elf
 *Pre-conditions:An elf has lost all of its lifepoints
 *Post-conditions:The elf is removed from the world
 *Return:None
 ****************************************************************/
void world::removeElf(string n){
   num_e-=1;
   int j;
   bool found =false;
   elf *temp=new elf[num_e];
   for(int i=0; i<num_e+1; i++){
      	if(found==false){
		j=i;
	}else{
		j=i-1;
	}
   	if(es[i].getName()!=n){
		temp[j]=es[i];
	}else{
		found=true;
	}
   }
   delete [] es;
   es=temp;
   cout<<"Your elf "<<n<<" is no longer in the world"<<endl;
}	
/******************************************************************
 *Function:removeCyber
 *Description:Deletes a cyberdemon that has no more life points, shrinks array by 1
 *Parameters:Name of cyberdemon
 *Pre-conditions:A cyberdemon has lost all of its lifepoints
 *Post-conditions:The cyberdemon is removed from the world
 *Return:None
 ****************************************************************/
void world::removeCyber(string n){
   num_c-=1;
   int j;
   bool found =false;
   cyber *temp=new cyber[num_c];
   for(int i=0; i<num_c+1; i++){
      	if(found==false){
		j=i;
	}else{
		j=i-1;
	}
   	if(cs[i].getName()!=n){
		temp[j]=cs[i];
	}else{
		found=true;
	}
   }
   delete [] cs;
   cs=temp;
   cout<<"Your cyberdemon "<<n<<" is no longer in the world"<<endl;
}	
/******************************************************************
 *Function:removeBalrog
 *Description:Deletes a balrog that has no more life points, shrinks array by 1
 *Parameters:Name of balrog
 *Pre-conditions:A balrog has lost all of its lifepoints
 *Post-conditions:The balrog is removed from the world
 *Return:None
 ****************************************************************/
void world::removeBalrog(string n){
   num_b-=1;
   int j;
   bool found =false;
   balrog *temp=new balrog[num_b];
   for(int i=0; i<num_b+1; i++){
      	if(found==false){
		j=i;
	}else{
		j=i-1;
	}
   	if(bs[i].getName()!=n){
		temp[j]=bs[i];
	}else{
		found=true;
	}
   }
   delete [] bs;
   bs=temp;
   cout<<"Your balrog "<<n<<" is no longer in the world"<<endl;
}	

/******************************************************************
 *Function:battle
 *Description:Two creature remove lifepoints from eachother, based on the damge they can inflict
 *Parameters:2 creature pointers
 *Pre-conditions:Creature pointers are defined and passed
 *Post-conditions:Both cretures have less lifepoints
 *Return:None
 ****************************************************************/
void world::battle(creature *c1, creature*c2){
   	int dam1=c1->getDamage();
	int dam2=c2->getDamage();
	c1->setLifePoints(c1->getLifePoints()-dam2);
	c2->setLifePoints(c2->getLifePoints()-dam1);
	if(dam1>dam2){
		money+=c1->getPayoff();
		cout<<c1->getName()<<" won this battle,causing "<<dam1<<" points of damge, while "<<c2->getName()<<" only caused "<<dam2<<". Your new balance is $"<<money<<endl;
	}else{
		money+=c2->getPayoff();	
		cout<<c2->getName()<<" won this battle,causing "<<dam2<<" points of damge, while "<<c1->getName()<<" only caused "<<dam1<<". Your new balance is $"<<money<<endl;
	}
	if(c1->getLifePoints()<=0){
		switch (c1->getType()){
			case 1: removeHuman(c1->getName());
				break;
			case 2: removeElf(c1->getName());
				break;
			case 3: removeCyber(c1->getName());
				break;
			case 4: removeBalrog(c1->getName());
				break;
		}
	}
	if(c2->getLifePoints()<=0){
		switch (c2->getType()){
			case 1: removeHuman(c1->getName());
				break;
			case 2: removeElf(c1->getName());
				break;
			case 3: removeCyber(c1->getName());
				break;
			case 4: removeBalrog(c1->getName());
				break;
		}
	}
}

/******************************************************************
 *Function:findHuman
 *Description:Searches for a human by name
 *Parameters:none
 *Pre-conditions:A human by the name exists
 *Post-conditions:None
 *Return:a human pointer
 ****************************************************************/
human* world::findHuman(){
   	string n;
	cout<<"Enter the name of the human: "<<endl;
	cin>>n;
	for (int i=0;i<num_h;i++){
		if(hs[i].getName()==n){
			return &hs[i];
		}
	}
}

/******************************************************************
 *Function:findElf
 *Description:Searches for an elf by name
 *Parameters:none
 *Pre-conditions:An elf by the name exists
 *Post-conditions:None
 *Return:an elf pointer
 ****************************************************************/
elf* world::findElf(){
   	string n;
	cout<<"Enter the name of the elf: "<<endl;;
	cin>>n;
	for (int i=0;i<num_e;i++){
		if(es[i].getName()==n){
			return &es[i];
		}
	}
}
/******************************************************************
 *Function:findCyber
 *Description:Searches for a cyberdemon by name
 *Parameters:none
 *Pre-conditions:A cyberdemon by the name exists
 *Post-conditions:None
 *Return:a cyberdemon pointer
 ****************************************************************/
cyber* world::findCyber(){
   	string n;
	cout<<"Enter the name of the cyberdemon: "<<endl;
	cin>>n;
	for (int i=0;i<num_c;i++){
		if(cs[i].getName()==n){
			return &cs[i];
		}
	}
}
/******************************************************************
 *Function:findBalrog
 *Description:Searches for a balrog by name
 *Parameters:none
 *Pre-conditions:A balrog by the name exists
 *Post-conditions:None
 *Return:a balrog pointer
 ****************************************************************/
balrog* world::findBalrog(){
   	string n;
	cout<<"Enter the name of the balrog: "<<endl;
	cin>>n;
	for (int i=0;i<num_b;i++){
		if(bs[i].getName()==n){
			return &bs[i];
		}
	}
}
/******************************************************************
 *Function:playGame
 *Description:Calls other functions to create gameplay
 *Parameters:None
 *Pre-conditions:A world eixsts
 *Post-conditions:The user' s money value has changed
 *Return:None
 ****************************************************************/
void world::playGame(){
	int numCreatures=2;
	int run=0;
	int choice;
	string s;
	creature *c1;
	creature *c2;
	int t;
	while(numCreatures>1||run<2){
		cout<<"Enter 1 to buy a creature or 2 to battle(You must have at least 2 creatures to battle): "<<endl;
		cin>>choice;
		if(choice==1){
			cout<<"Enter 1 to buy a human, 2 to buy an elf, 3 to buy a cyberdemon, and 4 to buy a balrog: "<<endl;
			   cin>>t;	
			switch (t){
				case 1: buyHuman();
					break;
				case 2: buyElf();
				
					break;
				case 3: buyCyber();
					break;
				case 4: buyBalrog();
					break;
			}
		}else{
			cout<<"Enter the type number of the first creature you would like to battle:"<<endl;
			cin>>t;
			switch (t){
				case 1: c1=findHuman();
					break;
				case 2: c1=findElf();
					break;
				case 3: c1=findCyber();
					break;
				case 4: c1=findBalrog();
					break;
			}	

			cout<<"Enter the type number of the second creature you would like to battle:"<<endl;
			cin>>t;
			switch (t){
				case 1: c2=findHuman();
					break;
				case 2: c2=findElf();
					break;
				case 3: c2=findCyber();
					break;
				case 4: c2=findBalrog();
					break;
			}
			battle(c1,c2);
		}
		run+=1;
		numCreatures=num_h+num_e+num_c+num_b;
		
	}

}
