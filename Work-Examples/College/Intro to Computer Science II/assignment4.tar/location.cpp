
/**********************************************************************
 *Program Filename:location.cpp
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description: Creates getters and setters for the location member variable
 *Input:None
 *Output:None
 ********************************************************************/
#include "location.h"
#include "event.h"
//getter:sets the value of the member variable
event * location::get_e(){
	return e;
} 
//setter:sets the value of the member variable
void location::set_e(event *i){
	e=i;
}
