
/**********************************************************************
 *Program Filename:pokemon.cpp
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:Sets up functionality of all its children classes, is a child of the event class
 *Input:None
 *Output:None
 ********************************************************************/
#include "pokemon.h"
#include <iostream>
#include <stdlib.h>
#include <time.h>
/*string pokemon::get_name(){
	return name;
}*/

pokemon::pokemon(){
	percept="Capture the ";
	percept+=name;
	percept+="nearby";
	//capture=100;
}
//getters: return the values of member variables
int pokemon::get_capture(){
	return capture;
}

int pokemon::get_evolve_num(){
	return evolve_num;
}

int pokemon::get_stage(){
	return stage;
}

bool pokemon::get_catch_fail(){
	return catch_fail;
}
/*void pokemon::set_name(string s){
	name=s;
}*/
//setters:set the values of member variables
void pokemon::set_capture(int i){
	capture=i;
}

void pokemon::set_evolve_num(int i){
	evolve_num=i;
}

void pokemon::set_stage(int i){
	stage=i;
}

void pokemon::set_catch_fail(bool b){
	catch_fail=b;
}
/************************************************************************
 *Function:captured
 *Description:Decides if a pokemon has been captured or not
 *Parameters:None
 *Pre-conditions:A pokemon has been created
 *Post-conditions:The pokemon may be captured, setting the value to true
 *Return:None
 ***********************************************************************/
void pokemon::captured(){
	srand (time(NULL));
	int r=rand()%100;
	//cout<<"r is: "<<r<<endl;
	//cout<<"capture is: "<<capture<<endl;
	if(r<capture){
		catch_fail=false;
	}else{
	catch_fail=true;}
}

/************************************************************************
 *Function:interaction
 *Description: The class that gives the interaction between the trainer and pokemon
 *Parameters:The trainer
 *Pre-conditions:A pokemon has been created and placed on the board, the trainer goes ther
 *Post-conditions:The pokemon may be captured
 *Return:None
 ***********************************************************************/
void pokemon::interaction(trainer &t){
   	int yn;
	cout<<"Would you like to attempt to capture the "<<name<<"?(enter 1 for yes, 0 for no):";
	cin>>yn;
	if(yn==1){
	   	if(t.get_pokeballs()>0){
			t.set_pokeballs(t.get_pokeballs()-1);
			captured();
			if(catch_fail==false){
			   	cout<<"You captured a/an "<<name<<endl;
				evolve_num-=1;
			}else{
				cout<<"You couldn't capture it :("<<endl;
			}
		}else{
			cout<<"You do not have any pokeballs. You must go get more first. Find a poke-stop."<<endl;
		}
	}
}
