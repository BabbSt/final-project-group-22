
/**********************************************************************
 *Program Filename:psychic.h
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:The header file for the psychic class
 *Input:None
 *Output:None
 ********************************************************************/
#include "pokemon.h"
class psychic: public pokemon{
   public:	
      psychic();
};
