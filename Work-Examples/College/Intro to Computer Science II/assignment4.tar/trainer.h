
/**********************************************************************
 *Program Filename:trainer.h
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description: The header file for the trainer class
 *Input:None
 *Output:None
 ********************************************************************/
#ifndef TRAINER_H
#define TRAINER_H
//#include "pokemon.h"
class trainer{
   private:
      int x;
      int y;
      int pokeballs;
      int pm[6];
   public:
      trainer();
      int get_x();
      int get_y();
      int get_pokeballs();
      int get_element_pm(int);
      void set_x(int);
      void set_y(int);
      void set_pokeballs(int);
      void set_element_pm(int, int);
};
#endif
