
/**********************************************************************
 *Program Filename:trainer.cpp
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:Holds the getters and setters for the trainer which represents the user
 *Input:None
 *Output:None
 ********************************************************************/
#include "trainer.h"

trainer::trainer(){
	pokeballs=3;
	for (int i=0;i<6;i++){
		pm[i]=0;
	}
}
//getters return member variables
int trainer::get_x(){
	return x;
}

int trainer::get_y(){
	return y;
}

int trainer::get_pokeballs(){
	return pokeballs;
}

int trainer::get_element_pm(int i){
   return pm[i];
}
//setters set the value of member variables
void trainer::set_x(int i){
	x=i;
}

void trainer::set_y(int i){
	y=i;
}

void trainer::set_pokeballs(int i){
	pokeballs=i;
}

void trainer::set_element_pm(int i, int j){
	pm[i]=j;
}
