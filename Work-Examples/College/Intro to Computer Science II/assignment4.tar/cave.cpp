
/**********************************************************************
 *Program Filename:cave.cpp
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description: Holds the constructor and interaction for a cave
 *Input:None
 *Output:None
 ********************************************************************/
#include "cave.h"
#include <iostream>
using namespace std;

cave::cave(){
   	percept="You see a precious stone nearby";
	name="cave";
}

/************************************************************************
 *Function:interaction
 *Description: The class that gives the interaction between the trainer and cave
 *Parameters:The trainer
 *Pre-conditions:A cave has been created and placed on the board, the trainer goes ther
 *Post-conditions:The pokemon may evolve
 *Return:None
 ***********************************************************************/
void cave::interaction(trainer &t){
	cout<<"You found a cave."<<endl;
	for (int i=0;i<6;i++){
		if(t.get_element_pm(i)==1){
		   	cout<<"You leveled up a pokemon"<<endl;
			t.set_element_pm(i,2);
		}
	}
}
