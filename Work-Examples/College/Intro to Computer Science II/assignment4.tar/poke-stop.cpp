
/**********************************************************************
 *Program Filename:poke-stop
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:Holds the constructor and interaction for a poke-stop
 *Input:None
 *Output:None
 ********************************************************************/
#include "poke-stop.h"
#include <stdlib.h>
#include <time.h>
#include <iostream>
using namespace std;
poke_stop::poke_stop(){
	percept="Fill up on poke-balls";
	name="pokestop";
}

/************************************************************************
 *Function:interaction
 *Description: The class that gives the interaction between the trainer and poke-stop
 *Parameters:The trainer
 *Pre-conditions:A poke-stop has been created and placed on the board, the trainer goes ther
 *Post-conditions:The trainer has more pokeballs
 *Return:None
 ***********************************************************************/
void poke_stop::interaction(trainer &t){
   	srand (time(NULL));
	int p=rand() %8 +3;
	t.set_pokeballs(t.get_pokeballs()+p);
	cout<<"You found "<<p<<" pokeballs"<<endl;
}
