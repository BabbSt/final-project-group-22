
/**********************************************************************
 *Program Filename: rock.h
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:The header file for the rock class
 *Input:None
 *Output:None
 ********************************************************************/
#include "pokemon.h"

class rock:  public pokemon{
   public:
      rock();
};
