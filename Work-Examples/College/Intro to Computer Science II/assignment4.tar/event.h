
/**********************************************************************
 *Program Filename: event.h
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:The header file for the event class
 *Input:None
 *Output:None
 ********************************************************************/
#ifndef EVENT_H
#define EVENT_H
#include <string>
#include "trainer.h"
using namespace std;
class event{
   protected:
	string percept;
	string name;
   public:
	string get_percept();
	string get_name();
	void set_percept(string);
	void set_name(string);
	virtual void interaction(trainer &t)=0;
};
#endif
