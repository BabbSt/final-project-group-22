
/**********************************************************************
 *Program Filename: location.h
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:The header file for the location class
 *Input:None
 *Output:None
 ********************************************************************/
#include "event.h"
class location{
   private:
   	event *e;
   public:
	event * get_e();
	void set_e(event *);
};
