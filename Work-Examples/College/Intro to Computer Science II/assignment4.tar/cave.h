
/**********************************************************************
 *Program Filename:cave.h
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:The header file for the cave class
 *Input:None
 *Output:None
 ********************************************************************/
#include "event.h"

class cave:public event{
	public:
	   cave();
	   void interaction(trainer &);
};
