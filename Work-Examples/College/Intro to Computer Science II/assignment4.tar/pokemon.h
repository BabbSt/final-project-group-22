
/**********************************************************************
 *Program Filename:pokemon.h
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:The header file for the pokemon class
 *Input:None
 *Output:None
 ********************************************************************/
#ifndef POKEMON_H
#define POKEMON_H
#include "event.h"
#include "trainer.h"
//#include <stdlib.h>
//#include <time.h>
using namespace std;
class pokemon:public event{
   protected:	
      //string name;
      bool catch_fail;
      int capture;
      int evolve_num;
      int stage;
      //int type;
   public:
      pokemon();
      int get_capture();
      int get_evolve_num();
      int get_stage();
      bool get_catch_fail();
      void set_capture(int);
      void set_evolve_num(int);
      void set_stage(int);
      void set_catch_fail(bool);
      void captured();
      void interaction(trainer &);
};
#endif
