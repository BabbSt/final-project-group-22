
/**********************************************************************
 *Program Filename:psychic.cpp
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:The constructor for a psychic type, sets the likelyhood of being captured
 *Input:None
 *Output:None
 ********************************************************************/
#include "psychic.h"
//#include <stdlib.h>
//#include <time.h>

psychic::psychic(){
	capture=25;
//	srand(time(NULL));
	evolve_num=1;
}
