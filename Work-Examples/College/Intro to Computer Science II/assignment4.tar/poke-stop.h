
/**********************************************************************
 *Program Filename: poke-stop.h
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:The header file for the poke-stop class
 *Input:None
 *Output:None
 ********************************************************************/
#include "event.h"
using namespace std;
class poke_stop: public event{
   public:
      poke_stop();
      void interaction(trainer &t);
};
