
/**********************************************************************
 *Program Filename:rock.cpp
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:The constructor for a rock type, sets the likelyhood of being captured
 *Input:None
 *Output:None
 ********************************************************************/
#include "rock.h"
//#include <stdlib.h>
//#include <time.h>
rock::rock(){
//	srand(time(NULL));
	capture=75;
	evolve_num=3;
}
