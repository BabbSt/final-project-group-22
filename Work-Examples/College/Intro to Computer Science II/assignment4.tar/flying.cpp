
/**********************************************************************
 *Program Filename:flying.cpp
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:The constructor for a flying type, sets the likelyhood of being captured
 *Input:None
 *Output:None
 ********************************************************************/
#include "flying.h"
//#include <stdlib.h>
//#include <time.h>

flying::flying(){
	capture=50;
	//srand(time(NULL));
	evolve_num=2;
}
