/**********************************************************************
 *Program Filename: driver.cpp
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description: Hold the main gameplay, uses other files to create, populate, and work with a board of location
 *Input: Some user input
 *Output:None
 ********************************************************************/
#include "location.h"
#include "trainer.h"
#include "pokemon.h"
#include "rock.h"
#include "psychic.h"
#include "flying.h"
#include "poke-stop.h"
#include "cave.h"
#include <iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

/************************************************************************
 *Function:print_percepts
 *Description: Prints the percepts of nearby events
 *Parameters:The board, the board size, the trainer position
 *Pre-conditions:A trainer has been created and placed on the board
 *Post-conditions:The percepts are printed
 *Return:None
 ***********************************************************************/
void print_percepts(location ***board, int r, int c, int y, int x){
   	if(x!=c-1&&(*board)[y][x+1].get_e()!=NULL){
		cout<<(*board)[y][x+1].get_e()->get_percept()<<endl;
	}
   	if(x!=0&&(*board)[y][x-1].get_e()!=NULL){
		cout<<(*board)[y][x-1].get_e()->get_percept()<<endl;
	}
   	if(y!=r-1&&(*board)[y+1][x].get_e()!=NULL){
		cout<<(*board)[y+1][x].get_e()->get_percept()<<endl;
	}
   	if(y!=0&&(*board)[y-1][x].get_e()!=NULL){
		cout<<(*board)[y-1][x].get_e()->get_percept()<<endl;
	}
	
}

/************************************************************************
 *Function:print_board
 *Description: goes through the borad and prints squares, the trainer is an x
 *Parameters:The borad size and the trainer location
 *Pre-conditions:The board has been created and the trainer is on it
 *Post-conditions:The board is printed
 *Return:None
 ***********************************************************************/
void print_board(int r, int c, int y, int x){
	for(int i=0; i<r;i++){
		for(int j=0;j<c;j++){
			cout<<"____";
		}
			cout<<endl;
		for(int k=0;k<c;k++){
		   	if(i==y&&k==x){
				cout<<"| X ";
			}else{
				cout<<"|   ";
			}
		}
		cout<<"|"<<endl;
	}
	for(int j=0;j<c;j++){
		cout<<"___";
	}
	cout<<endl;

}

/************************************************************************
 *Function:move
 *Description: Uses wasd to change the trainer position
 *Parameters:The trainer, the input variable, the size of the board
 *Pre-conditions:A trainer has been created and placed on the board, the input variable has been created
 *Post-conditions:The trainer moves, the board is printed
 *Return:None
 ***********************************************************************/
void move (trainer &t, char &i,int r, int c){
		//print_board(r,c,t.get_y(),t.get_x());
		cin>>i;
		switch(i){
		   case 'w':
		      t.set_y(t.get_y()-1);
		      break;
		   case 'a':
		      t.set_x(t.get_x()-1);
		      break;
		   case 's':
		      t.set_y(t.get_y()+1);
		      break;
		   case 'd':
		      t.set_x(t.get_x()+1);
		      break;
      		}		      
		print_board(r,c,t.get_y(),t.get_x());
}

/************************************************************************
 *Function:find_empty
 *Description: Finds a location without an event
 *Parameters:The board, the board size, x and y variables
 *Pre-conditions:the board has been created and has events
 *Post-conditions:the variables are set
 *Return:None
 ***********************************************************************/
void find_empty(location*** board,int &y, int &x, int r, int c){
	srand(time(NULL));
	while((*board)[y][x].get_e()!=NULL){
		x=rand()%c;
		y=rand()%r;
	}
}

/************************************************************************
 *Function:populate_board
 *Description: puts events on the board
 *Parameters:The board, the board size, the events
 *Pre-conditions:The board and events exits
 *Post-conditions:All events and the trainer are on the board
 *Return:None
 ***********************************************************************/
void populate_board(location ***board,int r, int c,poke_stop &ps, cave &ca, pokemon arr[], trainer &t, int &sx, int &sy){
   srand(time(NULL));
   (*board)[rand()%r][rand()%c].set_e(&ps);
   int x,y=0;
   find_empty(board,y,x,r,c);
   (*board)[y][x].set_e(&ca);
   for(int i=0;i<6;i++){
   	find_empty(board,y,x,r,c);
   	(*board)[y][x].set_e(&(arr[i]));
   }
   find_empty(board,y,x,r,c);
   t.set_x(x);
   t.set_y(y);
   sx=x;
   sy=y;

}

/************************************************************************
 *Function:move_pokemon (doesn' t work)
 *Description: 
 *Parameters:
 *Pre-conditions:
 *Post-conditions:
 *Return:None
 ***********************************************************************/
void move_pokemon(pokemon arr[], location ***board, int r, int c, int sx, int sy){
   	int open_y;
	int open_x;
   	bool full=true;
	for(int i=0;i<r;i++){
		for(int j=0;j<c; j++){
			if((*board)[i][j].get_e()==NULL&&(i!=sy||j!=sx)){
				full=false;
				open_y=i;
				open_x=j;
				break;
			}
		}
	}
	if(full==false){
	for(int i=0; i<6;i++){
		if(arr[i].get_catch_fail()==true){
		   	//cout<<arr[i].get_name()<<endl;
		   	for(int j=0;j<r;j++){
				for(int k=0;k<c;k++){
				   //cout<<(*board)[j][k].get_e()->get_name()<<endl;
					if(((*board)[j][k].get_e()!=NULL)&&((*board)[j][k].get_e()->get_name()==arr[i].get_name())){
						(*board)[open_y][open_x].set_e((*board)[j][k].get_e());
						(*board)[j][k].set_e(NULL);
					break;
					}
				}
			}
		}
	}
	}
}

/************************************************************************
 *Function:evolve
 *Description: If enough pokemon are caught they evolve to level 1
 *Parameters:The trainer and the array of pokemon
 *Pre-conditions:The pokemon array is filled
 *Post-conditions:Trainer array values change
 *Return:None
 ***********************************************************************/
void evolve(pokemon arr[], trainer &t){
	for(int i=0;i<6;i++){
		if(arr[i].get_evolve_num()==0){
			t.set_element_pm(i,1);
		}
	}
}

/************************************************************************
 *Function:all_evolved
 *Description:checks the winning requirements
 *Parameters:The trainer, the stating position
 *Pre-conditions:The user has played at least some of the game
 *Post-conditions:whether or not the user won is returned
 *Return:bool
 ***********************************************************************/
bool all_evolved(trainer &t, int sx, int sy){
	bool all=true;
	for(int i=0;i<6;i++){
		if(t.get_element_pm(i)!=2){
			all=false;
			break;
		}
	}
	if(t.get_x()!=sx){
		return false;
	}

	if(t.get_y()!=sy){
		return false;
	}

	return all;
}

int main(int argc, char *argv[]){
   	trainer t;
	poke_stop ps;
	cave ca;
	rock r1;
	rock r2;
	flying f1;
	flying f2;
	psychic p1;
	psychic p2;
	int sx;
	int sy;
	pokemon arr[6]={r1,r2,f1,f2,p1,p2};
	string narr[6]={"geodude","onix","charizard","rayaquaza","mewtwo","espeon"};
	for(int i=0;i<6;i++){
		arr[i].set_name(narr[i]);
	}
	int r=atoi(argv[1]);
	int c=atoi(argv[2]);
	if(atoi(argv [1])<3||atoi(argv[2])<3){
		cout<<"You have entered improper parameters for your board size. It  must be at minimum a 3x3. Please try again."<<endl;
	}
	location ** board;
	board= new location *[atoi(argv[1])];
	for (int i=0; i<atoi(argv[1]); i++){
		board[i]=new location[atoi(argv[2])];	
	}
	populate_board(&board, r, c, ps, ca, arr, t,sx,sy);
	print_board(atoi(argv[1]),atoi(argv[2]),t.get_y(),t.get_x());
	print_percepts(&board, r, c, t.get_y(),t.get_x());
	char i='k';
	bool cont=true;
	while(cont){
	   	cout<<"The trainer has "<<t.get_pokeballs()<<" pokeballs"<<endl;
		for(int j=0;j<6;j++){
			cout<<"You need to capture "<<arr[j].get_evolve_num()<<" more "<<arr[j].get_name()<<"s."<<endl;
		}
		move(t,i,r,c);
		if(board[t.get_y()][t.get_x()].get_e()!=NULL){
			board[t.get_y()][t.get_x()].get_e()->interaction(t);
		//move_pokemon(arr,&board,r,c,sx,sy);
		evolve(arr,t);
		print_percepts(&board, r, c, t.get_y(),t.get_x());
		}
		cont=!all_evolved(t,sx,sy);
	}
};
