
/**********************************************************************
 *Program Filename:event.cpp
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description: Pure virtual parent class of all events, has getters and setters for member variable
 *Input:None
 *Output:None
 ********************************************************************/
#include "event.h"
//getters:return the values of member variables
string event:: get_percept(){
	return percept;
}

string event::get_name(){
	return name;
}
//setters:set the value of member variables
void event:: set_percept(string s){
	percept=s;
}

void event::set_name(string s){
	name=s;
}
