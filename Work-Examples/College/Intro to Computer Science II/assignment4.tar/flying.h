
/**********************************************************************
 *Program Filename:flying.h
 *Author:Stephanie Babb
 *Date:May 29, 2017
 *Description:The header file for the flying class
 *Input:None
 *Output:None
 ********************************************************************/
#include "pokemon.h"
class flying:public pokemon{
   public:
      flying();
};
